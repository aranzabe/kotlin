enum class Tipos {Español, Bizantino}
