data class Aldeano(var salud:Int, var civ:Civilizacion)
